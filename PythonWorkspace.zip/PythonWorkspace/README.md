# Configuration du Bot Discord

## 1. Activer les Intents Privilégiés

1. Allez sur [Discord Developer Portal](https://discord.com/developers/applications)
2. Sélectionnez votre application
3. Dans "Bot", activez les 3 options sous "Privileged Gateway Intents":
   - PRESENCE INTENT
   - SERVER MEMBERS INTENT
   - MESSAGE CONTENT INTENT

## 2. Générer le lien d'invitation

1. Dans le portail développeur, allez dans "OAuth2" > "URL Generator"
2. Cochez les scopes suivants:
   - `bot`
   - `applications.commands`
3. Cochez les permissions bot suivantes:
   - Administrateur (pour simplifier) OU
   - Permissions spécifiques:
     - Gérer les rôles
     - Expulser des membres
     - Bannir des membres
     - Gérer les messages
     - Voir les salons
     - Envoyer des messages
     - Gérer les messages
     - Intégrer des liens
     - Joindre des fichiers
     - Voir l'historique des messages
     - Mentionner @everyone

4. Copiez l'URL générée et utilisez-la pour inviter le bot sur votre serveur

## 3. Commandes disponibles

Le bot utilise maintenant des commandes slash (/):
- `/kick` : Expulser un membre
- `/ban` : Bannir un membre
- `/unban` : Débannir un membre
- `/mute` : Rendre muet un membre
- `/warn` : Donner un avertissement
- `/warnings` : Voir les avertissements
- `/clear` : Supprimer des messages

## Configuration requise
Créez ces canaux sur votre serveur :
- `#bienvenue` : Pour les messages de bienvenue
- `#mod-logs` : Pour les logs de modération
